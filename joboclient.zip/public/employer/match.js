'user strict';

app.controller('ChatsCtrl', function ($scope) {
  $scope.settings = {
    enableFriends: true
  };
})
